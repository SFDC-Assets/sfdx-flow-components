({
    button1_Clicked: function(component, event, helper) {
        helper.setButtonClicked(component, "button1");
    },

    button2_Clicked: function(component, event, helper) {
        helper.setButtonClicked(component, "button2");
    },

    button3_Clicked: function(component, event, helper) {
        helper.setButtonClicked(component, "button3");
    },
});